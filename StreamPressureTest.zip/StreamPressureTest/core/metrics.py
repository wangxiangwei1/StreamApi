import statistics
from datetime import datetime

class Metrics:

    @staticmethod
    def percentile(data, p):
        if not data:
            return 0
        k = int(len(data) * p)
        k = min(k, len(data) - 1)
        return sorted(data)[k]

    @staticmethod
    def build_summary(writer, start_ts, end_ts, max_concurrency, results,
                      total_bytes, total_chars, peak_tps_all):
        duration = end_ts - start_ts
        totals = [r.get("total", 0) for r in results]
        ttfbs = [r.get("first", 0) for r in results if r.get("first", 0) > 0]
        success = sum(1 for r in results if r.get("success"))
        fail = len(results) - success
        peak_tps = max(peak_tps_all) if peak_tps_all else 0

        intervals = [i for r in results for i in r.get("intervals", [])]
        avg_interval = statistics.mean(intervals) if intervals else 0
        bytes_list = [r.get("bytes", 0) for r in results]
        avg_bytes = statistics.mean(bytes_list) if bytes_list else 0

        writer.writerow([]); writer.writerow([]); writer.writerow(["", "summary"])
        writer.writerow(["压测开始", datetime.fromtimestamp(start_ts).strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow(["压测结束", datetime.fromtimestamp(end_ts).strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow(["总时长(秒)", round(duration, 2)])
        writer.writerow(["最大并发", max_concurrency])
        writer.writerow(["总请求数", len(results)])
        writer.writerow(["成功数", success])
        writer.writerow(["失败数", fail])
        if results:
            writer.writerow(["成功率", f"{round(success/len(results)*100, 2)}%"])
        else:
            writer.writerow(["成功率", "0%"])
        writer.writerow(["峰值TPS", peak_tps])
        writer.writerow(["平均响应时间(秒)", round(statistics.mean(totals), 4) if totals else 0])
        writer.writerow(["P50响应(秒)", Metrics.percentile(totals, 0.5)])
        writer.writerow(["P90响应(秒)", Metrics.percentile(totals, 0.9)])
        writer.writerow(["P95响应(秒)", Metrics.percentile(totals, 0.95)])
        writer.writerow(["最小TTFB(秒)", min(ttfbs) if ttfbs else 0])
        writer.writerow(["最大TTFB(秒)", max(ttfbs) if ttfbs else 0])
        writer.writerow(["平均块间隔(秒)", round(avg_interval, 4)])
        writer.writerow(["平均块大小(Bytes)", round(avg_bytes, 2)])
        writer.writerow(["总字节(Bytes)", total_bytes])
        writer.writerow(["总字符(chars)", total_chars])
