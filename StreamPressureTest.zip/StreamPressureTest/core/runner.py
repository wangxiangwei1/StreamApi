import asyncio
import aiohttp
import csv
import os
import time
import json
import random
import string
import statistics
import contextlib
from datetime import datetime
import psutil

from utils.logger_manager import get_logger
from client.api_client import APIClient
from core.metrics import Metrics


class PressureRunner:
    def __init__(self, config):
        self.chat_url = config["server"]["chat_url"]
        self.callback_url = config["server"]["callback_url"]

        self.duration = int(''.join(filter(str.isdigit, config["test"]["duration"])))
        self.max_users = int(''.join(filter(str.isdigit, config["test"]["concurrent_users"])))
        self.ramp = int(''.join(filter(str.isdigit, config["test"]["ramp_up_per_second"])))

        self.preview = config["log"].getboolean("chunk_preview", fallback=True)
        self.preview_len = int(''.join(filter(str.isdigit, config["log"].get("chunk_preview_length", "80"))))

        token = config["auth"].get("x_new_auth", "")
        content_type = config["auth"].get("content_type", "application/json")

        self.csv_file = "results/all_in_one.csv"
        os.makedirs("results", exist_ok=True)

        with open("data/chat_payload.json", "r", encoding="utf-8") as f:
            self.base_chat_body = json.load(f)
        with open("data/questions.json", "r", encoding="utf-8") as f:
            self.questions = json.load(f)

        self.logger = get_logger("runner")
        self.client = APIClient(
            self.chat_url, self.callback_url, self.logger,
            preview=self.preview, preview_len=self.preview_len,
            content_type=content_type, x_new_auth=token
        )

        self.RESULTS = []
        self.REALTIME_SUCCESS = []
        self.PEAK_TPS = []
        self.TOTAL_BYTES = 0
        self.TOTAL_CHARS = 0

    def gen_id(self):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=48))

    def get_question(self, uid):
        return self.questions[(uid - 1) % len(self.questions)]

    async def run_one_user(self, session, uid, writer, current_concurrency, instant_tps, peak_tps, chunks_per_sec):
        body = self.base_chat_body.copy()
        body["conversationId"] = self.gen_id()
        body["inputText"] = self.get_question(uid)

        conversation_id = body["conversationId"]

        request_id = await self.client.get_request_id(session, body)
        if not request_id:
            self.RESULTS.append({"success": False, "total": 0, "first": 0, "count": 0,
                                 "bytes": 0, "chars": 0, "intervals": [], "reason": "requestId失败"})
            return

        r = await self.client.stream_callback(
            session, request_id, uid, conversation_id,
            current_concurrency=current_concurrency,
            instant_tps=instant_tps,
            peak_tps=peak_tps,
            chunks_per_sec=chunks_per_sec
        )

        writer.writerow([
            datetime.now().strftime("%H:%M:%S"), "callback", uid, request_id,
            round(r["total"], 4), r["count"], r["bytes"], r["chars"],
            round(r["first"], 4), r["success"], "", "", "", "", ""
        ])

        if r["success"]:
            self.REALTIME_SUCCESS.append(time.time())

        self.TOTAL_BYTES += r["bytes"]
        self.TOTAL_CHARS += r["chars"]
        self.RESULTS.append(r)

    async def stats_task(self, start, current_concurrent, writer):
        total_duration = self.duration
        last_net = psutil.net_io_counters()
        last_chunks = 0

        while True:
            await asyncio.sleep(1)
            now = time.time()
            elapsed = int(now - start)
            remaining = max(0, total_duration - elapsed)

            # 成功失败
            success = sum(1 for r in self.RESULTS if r.get("success"))
            fail = len(self.RESULTS) - success

            totals = [r.get("total", 0) for r in self.RESULTS]
            avg_resp = statistics.mean(totals) if totals else 0

            intervals = [i for r in self.RESULTS for i in r.get("intervals", [])]
            avg_interval = statistics.mean(intervals) if intervals else 0

            bytes_list = [r.get("bytes", 0) for r in self.RESULTS]
            avg_bytes = statistics.mean(bytes_list) if bytes_list else 0

            # TPS & 峰值
            threshold = now - 1
            instant_tps = sum(1 for t in self.REALTIME_SUCCESS if t >= threshold)
            self.PEAK_TPS.append(instant_tps)
            peak_tps = max(self.PEAK_TPS) if self.PEAK_TPS else instant_tps

            # 每秒块数
            total_chunks = sum(r.get("count", 0) for r in self.RESULTS)
            chunks_per_sec = total_chunks - last_chunks
            last_chunks = total_chunks

            # 网络带宽
            net = psutil.net_io_counters()
            sent = (net.bytes_sent - last_net.bytes_sent) / 1024
            recv = (net.bytes_recv - last_net.bytes_recv) / 1024
            last_net = net

            # CPU / 内存
            cpu = psutil.cpu_percent()
            mem = psutil.virtual_memory().percent

            # 进度条
            progress = elapsed / total_duration if total_duration > 0 else 1
            bar_len = 30
            filled_len = int(bar_len * progress)
            bar = "#" * filled_len + "-" * (bar_len - filled_len)
            percent = round(progress * 100, 1)

            print(
                f"""
[92m⏱ 已运行: {elapsed}/{total_duration} 秒[0m | [94m并发: {current_concurrent[0]}[0m | [92m✅成功: {success}[0m | [91m❌失败: {fail}[0m | [93m⚡TPS: {instant_tps}/s[0m | [95m🔺峰值TPS: {peak_tps}/s[0m
平均响应: {avg_resp:.3f}s | 块大小: {avg_bytes:.1f}B | 间隔: {avg_interval:.3f}s | 每秒块数: {chunks_per_sec}
[96m系统: CPU={cpu}% | 内存={mem}% | ↑上行={sent:.1f}KB/s | ↓下行={recv:.1f}KB/s[0m
进度: [{bar}] {percent}% 剩余 {max(0, remaining)}s"""
            )

            writer.writerow([
                datetime.now().strftime("%H:%M:%S"), "stats", "", "",
                "", "", "", "", "", "",
                cpu, mem, f"{sent:.1f}KB/s", f"{recv:.1f}KB/s",
                f"TPS={instant_tps}/s 峰值={peak_tps}/s 每秒块={chunks_per_sec} 平均响应={avg_resp:.3f}s 块={avg_bytes:.1f}B 间隔={avg_interval:.3f}s"
            ])

            # 将最新统计保存，供 run_one_user 传入详细 chunk 日志
            self._last_instant_tps = instant_tps
            self._last_peak_tps = peak_tps
            self._last_chunks_per_sec = chunks_per_sec

    async def start(self):
        start = time.time()
        current = 0
        current_concurrent = [0]

        write_header = not os.path.exists(self.csv_file)

        async with aiohttp.ClientSession() as session:
            with open(self.csv_file, "a", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)

                if write_header:
                    writer.writerow([
                        "时间","类型","用户编号","requestId","总耗时(s)","块数","字节数","字符数",
                        "首字节(s)","成功","CPU%","内存%","上行","下行","说明"
                    ])

                stat = asyncio.create_task(self.stats_task(start, current_concurrent, writer))
                tasks = set()

                try:
                    while time.time() - start < self.duration:
                        # 清理完成的任务
                        done = {t for t in tasks if t.done()}
                        tasks -= done

                        # ramp-up 到最大并发
                        if current < self.max_users:
                            current = min(current + self.ramp, self.max_users)
                            current_concurrent[0] = current
                            self.logger.info(f"[RAMP] 当前并发提升至 {current}")

                        # 补齐到目标并发
                        while len(tasks) < current:
                            uid = len(tasks) + 1
                            instant = getattr(self, "_last_instant_tps", 0)
                            peak = getattr(self, "_last_peak_tps", 0)
                            chunks_ps = getattr(self, "_last_chunks_per_sec", 0)
                            task = asyncio.create_task(self.run_one_user(
                                session, uid, writer,
                                current_concurrency=current_concurrent[0],
                                instant_tps=instant, peak_tps=peak, chunks_per_sec=chunks_ps
                            ))
                            tasks.add(task)

                        await asyncio.sleep(1)

                    # 等待剩余任务完成
                    if tasks:
                        await asyncio.gather(*tasks)

                finally:
                    with contextlib.suppress(asyncio.CancelledError):
                        stat.cancel()

                Metrics.build_summary(
                    writer, start, time.time(), current_concurrent[0],
                    self.RESULTS, self.TOTAL_BYTES, self.TOTAL_CHARS, self.PEAK_TPS
                )

        self.logger.info("✅ 压测结束，all_in_one.csv 已生成")
