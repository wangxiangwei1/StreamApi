import configparser
import asyncio
from core.runner import PressureRunner

if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read("config.ini", encoding="utf-8")
    runner = PressureRunner(config)
    asyncio.run(runner.start())
