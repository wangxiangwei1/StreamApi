import aiohttp
import time
import os
import psutil

class APIClient:
    def __init__(
        self, chat_url, callback_url, logger,
        preview=True, preview_len=80,
        content_type=None, x_new_auth=None
    ):
        self.chat_url = chat_url
        self.callback_url = callback_url
        self.logger = logger
        self.preview = preview
        self.preview_len = preview_len
        os.makedirs("logs", exist_ok=True)

        # headers
        self.headers = {"Content-Type": content_type or "application/json"}
        if x_new_auth:
            self.headers["x-new-auth"] = x_new_auth

        # single aggregate chunk log
        self.chunk_log_path = "logs/callback_chunks.log"

    async def get_request_id(self, session, payload):
        try:
            async with session.post(self.chat_url, json=payload, headers=self.headers) as resp:
                # allow non-JSON responses to be debugged
                try:
                    data = await resp.json()
                except Exception:
                    txt = await resp.text()
                    self.logger.error(f"[CHAT] 非JSON响应: {txt[:200]}")
                    return None
                req = data.get("requestId")
                if not req:
                    self.logger.error(f"[CHAT] 无 requestId 响应: {data}")
                return req
        except Exception as e:
            self.logger.error(f"[CHAT ERROR] {e}")
            return None

    async def stream_callback(self, session, request_id, uid, conversation_id,
                              current_concurrency=0, instant_tps=0, peak_tps=0, chunks_per_sec=0):
        params = {"requestId": request_id, "conversationId": conversation_id}

        start = time.time()
        chunk_count = 0
        first_chunk = None
        last_time = None
        total_bytes = 0
        chunk_intervals = []
        text = ""
        interrupted = False

        with open(self.chunk_log_path, "a", encoding="utf-8") as flog:
            flog.write(f"""
[开始] uid={uid} requestId={request_id} conversationId={conversation_id} time={time.strftime('%Y-%m-%d %H:%M:%S')}
""")

            # detailed system metrics snapshot (1s sampling for rates)
            try:
                cpu_times = psutil.cpu_times_percent()
                mem = psutil.virtual_memory()
                swap = psutil.swap_memory()
                disk_io_1 = psutil.disk_io_counters()
                net_1 = psutil.net_io_counters()
                time.sleep(1)  # sample window
                disk_io_2 = psutil.disk_io_counters()
                net_2 = psutil.net_io_counters()

                disk_read = (disk_io_2.read_bytes - disk_io_1.read_bytes) / 1024
                disk_write = (disk_io_2.write_bytes - disk_io_1.write_bytes) / 1024
                net_up = (net_2.bytes_sent - net_1.bytes_sent) / 1024
                net_down = (net_2.bytes_recv - net_1.bytes_recv) / 1024

                flog.write(
                    "\n系统监控:\n"
                    f"  CPU: user={cpu_times.user:.0f}% system={cpu_times.system:.0f}% idle={cpu_times.idle:.0f}% "
                    f"iowait={getattr(cpu_times, 'iowait', 0):.0f}%\n"
                    f"  内存: used={mem.used//1024//1024}MB available={mem.available//1024//1024}MB "
                    f"cached={getattr(mem, 'cached', 0)//1024//1024}MB swap={swap.used//1024//1024}MB\n"
                    f"  网络: ↑上行={net_up:.1f}KB/s ↓下行={net_down:.1f}KB/s\n"
                    f"  磁盘: 读={disk_read:.1f}KB/s 写={disk_write:.1f}KB/s\n"
                )
            except Exception as e:
                flog.write(f"[系统监控异常]: {e}\n")

            # pressure status line
            status = f"压测状态:\n  并发={current_concurrency} 当前TPS={instant_tps} 峰值TPS={peak_tps} 每秒块={chunks_per_sec}"
            if peak_tps and instant_tps == peak_tps:
                status += " (🔥达到峰值)"
            flog.write(status + "\n")

            try:
                async with session.get(self.callback_url, params=params, headers=self.headers) as resp:
                    # Optionally log status code
                    flog.write(f"[HTTP] 状态码={resp.status}\n")
                    async for chunk in resp.content.iter_chunked(1024):
                        now = time.time()
                        size = len(chunk)
                        chunk_count += 1
                        total_bytes += size

                        if chunk_count == 1:
                            first_chunk = now - start
                            flog.write(f"[块1] 首字节={first_chunk:.4f}s 大小={size}B\n")
                        else:
                            interval = now - last_time
                            chunk_intervals.append(interval)
                            flog.write(f"[块{chunk_count}] 间隔={interval:.4f}s 大小={size}B\n")

                        if self.preview:
                            try:
                                txt = chunk.decode(errors="ignore")
                                text += txt
                                pv = txt.strip().replace("\n", " ")[:self.preview_len]
                                if pv:
                                    flog.write(f"预览: {pv}\n")
                            except Exception:
                                pass

                        last_time = now

            except Exception as e:
                interrupted = True
                flog.write(f"[异常] {e}\n")

            total_time = time.time() - start
            flog.write(f"[结束] 块数={chunk_count}, 字节={total_bytes}, 总耗时={total_time:.4f}s\n")
            flog.write("------------------------------------------------------------\n")

        success = (not interrupted and chunk_count > 0)
        return {
            "success": success,
            "total": total_time,
            "first": first_chunk or 0,
            "count": chunk_count,
            "bytes": total_bytes,
            "chars": len(text),
            "intervals": chunk_intervals
        }
