# 流式接口压测框架说明文档

本框架提供 callback（双接口）、sopAgent、agentAnswer 三种压测模式，支持流式响应的完整性能指标采集。

## 📁 框架目录结构
```
stream_load_test/
├── config.ini
├── main.py
├── core/
│   ├── logger.py
│   ├── config_loader.py
│   ├── metrics.py
│   ├── system_monitor.py
│   └── runner.py
├── clients/
│   ├── base_client.py
│   ├── dual_client.py
│   └── stream_client.py
├── first_token/
│   ├── __init__.py
│   └── first_token_recorder.py
├── data/
│   ├── questions.json
│   ├── dual_chat_payload.json
│   ├── stream_a_payload.json
│   └── stream_b_payload.json
└── results/
    ├── csv/
    └── logs/
```

## ✨ 核心功能
### ✔ 支持三种模式
- callback（chat + callback）
- sopAgent
- agentAnswer

### ✔ 压测逻辑
- 支持 ramp-up（每秒新增用户）
- 支持最大并发后保持压力
- 支持统计开始/结束时间
- 支持流式 chunk 指标采集

### ✔ 指标采集（全中文 CSV）
- TTFB（首字节时间）
- 首Token时间
- 响应总耗时
- 流式持续时间
- 平均块大小
- 平均块间隔
- Chunk 数
- CPU 使用率
- 内存使用率
- 网络带宽
- TPS
- P50 / P90 / P95 / P99

### ✔ 输出文件
- results/csv/details_*.csv（明细）
- results/csv/summary_*.csv（汇总）
- results/csv/first_token_curve_*.csv（首Token曲线）
- logs/run_*.log

## 📌 使用步骤
1. 编辑 config.ini 配置接口和压力策略  
2. 在 data/ 中填充 payload 和 question 数据  
3. 执行 main.py 开始压测：  
```
python main.py
```

## 🔥 注意事项
- CSV 使用 UTF-8 BOM，可避免 Excel 打开乱码
- 所有日志与结果自动归档
- 可扩展更多 headers 进入 config.ini
