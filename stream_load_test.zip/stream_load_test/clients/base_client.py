# clients/base_client.py
import asyncio
import time
import uuid
import random
import aiohttp
from core.metrics import RequestMetric

class BaseClient:
    def __init__(
        self,
        user_id,
        urls,
        headers,
        payload,
        questions,
        metrics,
        first_token_recorder,
        logger
    ):
        self.user_id = user_id
        self.urls = urls
        self.headers = headers
        self.payload = payload
        self.questions = questions
        self.metrics = metrics
        self.first_token_recorder = first_token_recorder
        self.logger = logger
        self.session = None

    async def _ensure_session(self):
        if self.session is None:
            timeout = aiohttp.ClientTimeout(total=600)
            self.session = aiohttp.ClientSession(timeout=timeout)

    def _random_question(self):
        return random.choice(self.questions) if self.questions else "你好"

    def _random_conversation_id(self):
        return uuid.uuid4().hex + uuid.uuid4().hex[:16]

    def _record_first_token(self, t):
        self.first_token_recorder.add_point(
            timestamp=time.time(),
            user_id=self.user_id,
            current_users=self.metrics.current_users,
            first_token_ms=t * 1000
        )

    def _save_request_metric(
        self, mode, step, method, url, status_code, success,
        error_type, error_message,
        ttfb, total_time, bytes_received, chunks,
        avg_chunk_interval, avg_chunk_size
    ):
        m = RequestMetric(
            timestamp=time.time(),
            user_id=self.user_id,
            mode=mode,
            step=step,
            method=method,
            url=url,
            status_code=status_code,
            success=success,
            error_type=error_type,
            error_message=error_message,
            ttfb=ttfb,
            total_time=total_time,
            bytes_received=bytes_received,
            chunks=chunks,
            avg_chunk_interval=avg_chunk_interval,
            avg_chunk_size=avg_chunk_size,
            bucket_second=int(time.time())
        )
        self.metrics.add_record(m)

    async def _stream_request(self, url, method, json_payload, mode, step):
        await self._ensure_session()

        start = time.time()
        first_token = None
        chunk_count = 0
        bytes_received = 0
        chunk_intervals = []
        last_chunk_time = None

        status = 0
        error_type = ""
        error_message = ""

        try:
            async with self.session.request(
                method=method,
                url=url,
                headers=self.headers,
                json=json_payload
            ) as resp:
                status = resp.status

                async for raw in resp.content:
                    now = time.time()

                    if first_token is None:
                        first_token = now - start
                        self._record_first_token(first_token)
                        self.logger.info("[用户 %s] 首个Token时间: %.3fs", self.user_id, first_token)

                    bytes_received += len(raw)
                    chunk_count += 1

                    if last_chunk_time:
                        chunk_intervals.append(now - last_chunk_time)
                    last_chunk_time = now

        except Exception as e:
            error_type = "exception"
            error_message = str(e)
            self.logger.error("[用户 %s] 请求异常: %s", self.user_id, e)

        total_time = time.time() - start
        avg_interval = (sum(chunk_intervals) / len(chunk_intervals)) if chunk_intervals else None
        avg_size = (bytes_received / chunk_count) if chunk_count else None

        self._save_request_metric(
            mode=mode,
            step=step,
            method=method,
            url=url,
            status_code=status,
            success=(status == 200 and not error_type),
            error_type=error_type,
            error_message=error_message,
            ttfb=first_token,
            total_time=total_time,
            bytes_received=bytes_received,
            chunks=chunk_count,
            avg_chunk_interval=avg_interval,
            avg_chunk_size=avg_size
        )

        return {
            "status": status,
            "first_token": first_token,
            "total_time": total_time,
            "chunks": chunk_count,
            "bytes_received": bytes_received
        }

    async def run(self):
        raise NotImplementedError("子类必须实现 run()")
