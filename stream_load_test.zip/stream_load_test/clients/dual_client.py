# clients/dual_client.py
import json
import time
from clients.base_client import BaseClient

class DualClient(BaseClient):
    async def run(self):
        await self._ensure_session()

        question = self._random_question()
        conversation_id = self._random_conversation_id()

        chat_payload = self.payload.copy()
        chat_payload["inputText"] = question
        chat_payload["conversationId"] = conversation_id

        self.logger.info("[用户 %s] chat 请求开始，conversationId=%s", self.user_id, conversation_id)

        start_chat = time.time()
        chat_status = 0
        response_text = ""

        try:
            async with self.session.post(
                self.urls["chat"],
                headers=self.headers,
                json=chat_payload
            ) as resp:
                chat_status = resp.status
                response_text = await resp.text()
        except Exception as e:
            self.logger.error("[用户 %s] chat 请求异常: %s", self.user_id, e)

        total_chat_time = time.time() - start_chat

        request_id = None
        if chat_status == 200:
            try:
                data = json.loads(response_text)
                request_id = data.get("requestId")
            except:
                request_id = None

        self._save_request_metric(
            mode="callback",
            step="chat",
            method="POST",
            url=self.urls["chat"],
            status_code=chat_status,
            success=(chat_status == 200 and request_id is not None),
            error_type="" if request_id else "chat_no_requestId",
            error_message="未获取 requestId" if not request_id else "",
            ttfb=None,
            total_time=total_chat_time,
            bytes_received=len(response_text),
            chunks=1,
            avg_chunk_interval=None,
            avg_chunk_size=None
        )

        if not request_id:
            self.logger.error("[用户 %s] chat 未返回 requestId，跳过 callback", self.user_id)
            return

        callback_url = f"{self.urls['callback']}?requestId={request_id}"
        self.logger.info("[用户 %s] 开始 callback 流式请求 %s", self.user_id, callback_url)

        await self._stream_request(
            url=callback_url,
            method="GET",
            json_payload=None,
            mode="callback",
            step="callback"
        )
