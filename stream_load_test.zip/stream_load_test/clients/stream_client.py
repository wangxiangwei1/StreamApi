# clients/stream_client.py
from clients.base_client import BaseClient

class StreamClient(BaseClient):
    def __init__(
        self,
        user_id,
        url,
        headers,
        payload,
        questions,
        metrics,
        first_token_recorder,
        logger,
        mode
    ):
        super().__init__(
            user_id=user_id,
            urls={"stream": url},
            headers=headers,
            payload=payload,
            questions=questions,
            metrics=metrics,
            first_token_recorder=first_token_recorder,
            logger=logger
        )
        self.stream_url = url
        self.mode = mode

    async def run(self):
        await self._ensure_session()
        question = self._random_question()

        payload = self.payload.copy()
        payload["inputText"] = question

        self.logger.info("[用户 %s] %s 流式请求开始", self.user_id, self.mode)

        await self._stream_request(
            url=self.stream_url,
            method="POST",
            json_payload=payload,
            mode=self.mode,
            step="stream"
        )
