# first_token/first_token_recorder.py
import os
import csv
from datetime import datetime

class FirstTokenRecorder:
    def __init__(self):
        self.records = []

    def add_point(self, timestamp, user_id, current_users, first_token_ms):
        self.records.append({
            "timestamp": timestamp,
            "user_id": user_id,
            "current_users": current_users,
            "first_token_ms": first_token_ms
        })

    def export_csv(self, output_dir="results/csv"):
        os.makedirs(output_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(output_dir, f"first_token_curve_{ts}.csv")

        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["时间戳", "用户ID", "当前并发数", "首个Token时间(ms)"])
            for r in self.records:
                w.writerow([
                    r["timestamp"],
                    r["user_id"],
                    r["current_users"],
                    r["first_token_ms"]
                ])
        return path
