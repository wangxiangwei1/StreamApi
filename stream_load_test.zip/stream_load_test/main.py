# main.py
import asyncio
from core.logger import setup_logger
from core.config_loader import ConfigLoader
from core.metrics import MetricsCollector
from core.runner import PressureRunner
from first_token.first_token_recorder import FirstTokenRecorder

async def main():
    logger, log_file = setup_logger()
    logger.info("压测框架启动")

    cfg = ConfigLoader("config.ini")
    mode = cfg.get_mode()
    urls = cfg.get_urls()
    headers = cfg.get_headers()
    pressure = cfg.get_pressure()
    data_payloads = cfg.get_payloads()
    questions = cfg.get_questions()

    metrics = MetricsCollector()
    first_token_recorder = FirstTokenRecorder()

    runner = PressureRunner(
        mode=mode,
        urls=urls,
        headers=headers,
        pressure=pressure,
        data_payloads=data_payloads,
        questions=questions,
        metrics=metrics,
        first_token_recorder=first_token_recorder,
        logger=logger
    )

    await runner.run_test()
    ft_csv = first_token_recorder.export_csv()
    logger.info("首Token曲线 CSV 已导出: %s", ft_csv)
    logger.info("全部任务完成，日志文件: %s", log_file)

if __name__ == "__main__":
    asyncio.run(main())
