# core/system_monitor.py
import psutil
import time

class SystemMonitor:
    def __init__(self):
        self.last_sent = psutil.net_io_counters().bytes_sent
        self.last_recv = psutil.net_io_counters().bytes_recv
        self.last_time = time.time()

    def get_metrics(self):
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent

        now = time.time()
        interval = now - self.last_time if now > self.last_time else 1

        net = psutil.net_io_counters()
        sent_diff = net.bytes_sent - self.last_sent
        recv_diff = net.bytes_recv - self.last_recv

        up_kb = sent_diff / 1024 / interval
        down_kb = recv_diff / 1024 / interval

        self.last_sent = net.bytes_sent
        self.last_recv = net.bytes_recv
        self.last_time = now

        return cpu, mem, up_kb, down_kb
