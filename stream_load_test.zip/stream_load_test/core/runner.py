# core/runner.py
import asyncio
import random
from datetime import datetime

from clients.dual_client import DualClient
from clients.stream_client import StreamClient
from core.system_monitor import SystemMonitor

class PressureRunner:
    def __init__(
        self,
        mode,
        urls,
        headers,
        pressure,
        data_payloads,
        questions,
        metrics,
        first_token_recorder,
        logger
    ):
        self.mode = mode
        self.urls = urls
        self.headers = headers
        self.pressure = pressure
        self.payloads = data_payloads
        self.questions = questions
        self.metrics = metrics
        self.first_token_recorder = first_token_recorder
        self.logger = logger

        self.monitor = SystemMonitor()
        self.user_counter = 0

    def _create_client(self, user_id):
        if self.mode == "callback":
            return DualClient(
                user_id=user_id,
                urls=self.urls,
                headers=self.headers,
                payload=self.payloads["dual_chat_payload"],
                questions=self.questions,
                metrics=self.metrics,
                first_token_recorder=self.first_token_recorder,
                logger=self.logger
            )
        elif self.mode == "sopAgent":
            return StreamClient(
                user_id=user_id,
                url=self.urls["stream_a"],
                headers=self.headers,
                payload=self.payloads["stream_a_payload"],
                questions=self.questions,
                metrics=self.metrics,
                first_token_recorder=self.first_token_recorder,
                logger=self.logger,
                mode=self.mode
            )
        elif self.mode == "agentAnswer":
            return StreamClient(
                user_id=user_id,
                url=self.urls["stream_b"],
                headers=self.headers,
                payload=self.payloads["stream_b_payload"],
                questions=self.questions,
                metrics=self.metrics,
                first_token_recorder=self.first_token_recorder,
                logger=self.logger,
                mode=self.mode
            )
        else:
            raise ValueError(f"未知模式: {self.mode}")

    async def _run_user(self, user_id):
        client = self._create_client(user_id)
        await client.run()

    async def _system_monitor_task(self):
        while True:
            cpu, mem, up, down = self.monitor.get_metrics()
            self.metrics.add_system_metrics(cpu, mem, up, down)
            await asyncio.sleep(1)

    async def _run_pressure(self):
        duration = self.pressure["duration"]
        max_users = self.pressure["max_users"]
        ramp = self.pressure["ramp_up_per_second"]

        self.logger.info("压测开始: 持续=%ss, 最大并发=%s, 每秒新增=%s", duration, max_users, ramp)

        asyncio.create_task(self._system_monitor_task())

        start_ts = datetime.now().timestamp()
        end_ts = start_ts + duration

        tasks = []

        while True:
            now = datetime.now().timestamp()
            if now >= end_ts:
                break

            if self.metrics.current_users < max_users:
                for _ in range(ramp):
                    if self.metrics.current_users >= max_users:
                        break

                    self.user_counter += 1
                    user_id = self.user_counter

                    self.logger.info(
                        "新增用户 -> %s，当前并发=%s，剩余=%ss",
                        user_id, self.metrics.current_users + 1, int(end_ts - now)
                    )

                    t = asyncio.create_task(self._run_user(user_id))
                    tasks.append(t)
                    self.metrics.current_users += 1

            await asyncio.sleep(1)

        await asyncio.gather(*tasks, return_exceptions=True)

    async def run_test(self):
        self.metrics.start_time = datetime.now()
        self.logger.info("压测开始时间: %s", self.metrics.start_time)

        await self._run_pressure()

        self.metrics.end_time = datetime.now()
        self.logger.info("压测结束时间: %s", self.metrics.end_time)

        details_path = self.metrics.export_details()
        self.logger.info("明细 CSV 已导出: %s", details_path)

        summary_path = self.metrics.export_summary()
        self.logger.info("汇总 CSV 已导出: %s", summary_path)
