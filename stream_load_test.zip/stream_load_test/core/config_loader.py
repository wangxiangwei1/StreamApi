# core/config_loader.py
import json
import configparser
import os

class ConfigLoader:
    def __init__(self, ini_path: str):
        if not os.path.exists(ini_path):
            raise FileNotFoundError(f"配置文件不存在: {ini_path}")
        self.config = configparser.ConfigParser()
        self.config.read(ini_path, encoding="utf-8")

    def get_mode(self) -> str:
        return self.config["mode"]["type"].strip()

    def get_urls(self) -> dict:
        urls = self.config["urls"]
        return {
            "chat": urls.get("chat", "").strip(),
            "callback": urls.get("callback", "").strip(),
            "stream_a": urls.get("stream_a", "").strip(),
            "stream_b": urls.get("stream_b", "").strip(),
        }

    def get_headers(self) -> dict:
        raw = self.config["headers"]
        headers = {}
        for key in raw:
            headers[key] = raw[key]
        return headers

    def get_pressure(self) -> dict:
        c = self.config["pressure"]
        return {
            "duration": int(c.get("duration", "60")),
            "max_users": int(c.get("max_users", "10")),
            "ramp_up_per_second": int(c.get("ramp_up_per_second", "1")),
        }

    def get_payloads(self) -> dict:
        base = "data"

        def load_json(name):
            path = os.path.join(base, name)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            return {}

        return {
            "dual_chat_payload": load_json("dual_chat_payload.json"),
            "stream_a_payload": load_json("stream_a_payload.json"),
            "stream_b_payload": load_json("stream_b_payload.json"),
        }

    def get_questions(self) -> list:
        path = os.path.join("data", "questions.json")
        if not os.path.exists(path):
            return []
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
