# core/metrics.py
import os
import csv
import statistics
from datetime import datetime

class RequestMetric:
    def __init__(
        self,
        timestamp,
        user_id,
        mode,
        step,
        method,
        url,
        status_code,
        success,
        error_type,
        error_message,
        ttfb,
        total_time,
        bytes_received,
        chunks,
        avg_chunk_interval,
        avg_chunk_size,
        bucket_second
    ):
        self.timestamp = timestamp
        self.user_id = user_id
        self.mode = mode
        self.step = step
        self.method = method
        self.url = url
        self.status_code = status_code
        self.success = success
        self.error_type = error_type
        self.error_message = error_message
        self.ttfb = ttfb
        self.total_time = total_time
        self.bytes_received = bytes_received
        self.chunks = chunks
        self.avg_chunk_interval = avg_chunk_interval
        self.avg_chunk_size = avg_chunk_size
        self.bucket_second = bucket_second

class MetricsCollector:
    def __init__(self):
        self.records = []
        self.cpu_list = []
        self.mem_list = []
        self.upload_kb_list = []
        self.download_kb_list = []
        self.start_time = None
        self.end_time = None
        self.current_users = 0

    def add_record(self, metric: RequestMetric):
        self.records.append(metric)

    def add_system_metrics(self, cpu, mem, up_kb, down_kb):
        self.cpu_list.append(cpu)
        self.mem_list.append(mem)
        self.upload_kb_list.append(up_kb)
        self.download_kb_list.append(down_kb)

    def export_details(self, output_dir="results/csv"):
        os.makedirs(output_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(output_dir, f"details_{ts}.csv")

        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([
                "时间戳","用户ID","模式","阶段","请求方法","请求URL","状态码","是否成功",
                "错误类型","错误信息","首字节时间(ms)","总耗时(ms)","接收字节数",
                "数据块数量","平均块间隔(ms)","平均块大小(Byte)","TPS时间秒"
            ])
            for r in self.records:
                w.writerow([
                    r.timestamp, r.user_id, r.mode, r.step, r.method, r.url,
                    r.status_code, "成功" if r.success else "失败",
                    r.error_type, r.error_message,
                    r.ttfb*1000 if r.ttfb else "",
                    r.total_time*1000,
                    r.bytes_received, r.chunks,
                    r.avg_chunk_interval*1000 if r.avg_chunk_interval else "",
                    r.avg_chunk_size if r.avg_chunk_size else "",
                    r.bucket_second
                ])
        return path

    def export_summary(self, output_dir="results/csv"):
        os.makedirs(output_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(output_dir, f"summary_{ts}.csv")

        total = len(self.records)
        success = len([r for r in self.records if r.success])
        failed = total - success
        times = [r.total_time*1000 for r in self.records]
        ttfb_times = [r.ttfb*1000 for r in self.records if r.ttfb]
        stream_times = [
            (r.total_time - (r.ttfb if r.ttfb else 0))*1000
            for r in self.records
        ]
        chunks_all = [r.chunks for r in self.records]
        avg_sizes = [r.avg_chunk_size for r in self.records if r.avg_chunk_size]
        avg_intervals = [
            r.avg_chunk_interval*1000 for r in self.records if r.avg_chunk_interval
        ]

        if self.start_time and self.end_time:
            duration = (self.end_time - self.start_time).total_seconds()
            avg_tps = total / duration if duration>0 else 0
        else:
            avg_tps = 0

        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["压测开始时间", self.start_time.strftime("%Y-%m-%d %H:%M:%S")])
            w.writerow(["压测结束时间", self.end_time.strftime("%Y-%m-%d %H:%M:%S")])
            w.writerow(["模式", self.records[0].mode if self.records else ""])
            w.writerow(["最大并发数", self.current_users])
            w.writerow(["总请求数", total])
            w.writerow(["成功数", success])
            w.writerow(["失败数", failed])
            w.writerow(["平均响应时间(ms)", statistics.mean(times) if times else ""])
            w.writerow(["最小响应时间(ms)", min(times) if times else ""])
            w.writerow(["最大响应时间(ms)", max(times) if times else ""])
            w.writerow(["P50响应时间(ms)", statistics.median(times) if times else ""])
            w.writerow(["P90响应时间(ms)", statistics.quantiles(times, n=10)[8] if len(times)>=10 else ""])
            w.writerow(["P95响应时间(ms)", statistics.quantiles(times, n=20)[18] if len(times)>=20 else ""])
            w.writerow(["P99响应时间(ms)", statistics.quantiles(times, n=100)[98] if len(times)>=100 else ""])
            w.writerow(["平均首字节时间(ms)", statistics.mean(ttfb_times) if ttfb_times else ""])
            w.writerow(["平均流式持续时间(ms)", statistics.mean(stream_times) if stream_times else ""])
            w.writerow(["总块数", sum(chunks_all)])
            w.writerow(["平均块大小(Byte)", statistics.mean(avg_sizes) if avg_sizes else ""])
            w.writerow(["平均块间隔(ms)", statistics.mean(avg_intervals) if avg_intervals else ""])
            w.writerow(["平均TPS", avg_tps])
            w.writerow(["平均CPU使用率(%)", statistics.mean(self.cpu_list) if self.cpu_list else ""])
            w.writerow(["平均内存使用率(%)", statistics.mean(self.mem_list) if self.mem_list else ""])
            w.writerow(["平均上行带宽(KB/s)", statistics.mean(self.upload_kb_list) if self.upload_kb_list else ""])
            w.writerow(["平均下行带宽(KB/s)", statistics.mean(self.download_kb_list) if self.download_kb_list else ""])

        return path
