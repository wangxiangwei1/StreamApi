import random
import string


def generate_conversation_id(length: int = 48) -> str:
    """生成随机 48 位会话 ID（字母 + 数字）。"""
    chars = string.ascii_letters + string.digits
    return "".join(random.choice(chars) for _ in range(length))
