from __future__ import annotations

import json
from itertools import cycle
from pathlib import Path
from typing import Any, List, Dict


class DataLoader:
    """负责从 data 目录加载问题、各接口 payload，并提供轮询。"""

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = Path(data_dir)

        self.questions: List[str] = self._load("questions.json")
        self.chat_payloads: List[Dict[str, Any]] = self._load("chat_payloads.json")
        self.stream_a_payloads: List[Dict[str, Any]] = self._load("stream_a_payloads.json")
        self.stream_b_payloads: List[Dict[str, Any]] = self._load("stream_b_payloads.json")

        self._q_cycle = cycle(self.questions)
        self._chat_cycle = cycle(self.chat_payloads)
        self._a_cycle = cycle(self.stream_a_payloads)
        self._b_cycle = cycle(self.stream_b_payloads)

    def _load(self, name: str):
        path = self.data_dir / name
        if not path.exists():
            raise FileNotFoundError(f"数据文件不存在: {path}")
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def next_question(self) -> str:
        return next(self._q_cycle)

    def next_chat_payload(self) -> Dict[str, Any]:
        import copy
        return copy.deepcopy(next(self._chat_cycle))

    def next_stream_a_payload(self) -> Dict[str, Any]:
        import copy
        return copy.deepcopy(next(self._a_cycle))

    def next_stream_b_payload(self) -> Dict[str, Any]:
        import copy
        return copy.deepcopy(next(self._b_cycle))
