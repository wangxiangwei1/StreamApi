from __future__ import annotations

import csv
import statistics
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Any


@dataclass
class RequestRecord:
    """单次请求的详细指标。"""

    mode: str
    ok: bool
    time_cost: float          # 整体耗时（秒）
    ttfb: float               # 首字节时间（秒）
    stream_cost: float        # 流式持续时间（秒）
    chunks: int               # 块数
    chunk_sizes: List[int] = field(default_factory=list)
    chunk_intervals: List[float] = field(default_factory=list)  # 每块间隔（秒）
    cpu: float | None = None
    mem: float | None = None


class ResultRecorder:
    """负责保存请求记录、系统采样，并提供汇总统计 + CSV 写入。"""

    def __init__(self, csv_path: Path) -> None:
        self.records: List[RequestRecord] = []
        self.csv_path = csv_path

        self.cpu_samples: List[float] = []
        self.mem_samples: List[float] = []
        self.net_up_samples: List[float] = []
        self.net_down_samples: List[float] = []

    # —— 单次请求记录 —— #
    def add_record(self, record: RequestRecord) -> None:
        self.records.append(record)

    # —— 系统采样记录 —— #
    def add_system_sample(self, cpu: float, mem: float, up_kb: float, down_kb: float) -> None:
        self.cpu_samples.append(cpu)
        self.mem_samples.append(mem)
        self.net_up_samples.append(up_kb)
        self.net_down_samples.append(down_kb)

    # —— 百分位 —— #
    @staticmethod
    def _percentile(data: List[float], p: float) -> float:
        if not data:
            return 0.0
        data = sorted(data)
        k = (len(data) - 1) * (p / 100.0)
        f = int(k)
        c = min(f + 1, len(data) - 1)
        if f == c:
            return data[f]
        d0 = data[f] * (c - k)
        d1 = data[c] * (k - f)
        return d0 + d1

    # —— 汇总统计 —— #
    def aggregate(self) -> dict[str, Any]:
        if not self.records:
            return {}

        latencies = [r.time_cost * 1000 for r in self.records]  # ms
        ttfb_list = [r.ttfb * 1000 for r in self.records if r.ttfb > 0]
        stream_list = [r.stream_cost * 1000 for r in self.records if r.stream_cost > 0]

        all_sizes: List[int] = []
        all_intervals: List[float] = []
        total_chunks = 0

        for r in self.records:
            total_chunks += r.chunks
            all_sizes.extend(r.chunk_sizes)
            all_intervals.extend([x * 1000 for x in r.chunk_intervals])  # 转 ms

        avg_latency = statistics.mean(latencies)
        min_latency = min(latencies)
        max_latency = max(latencies)
        p50 = self._percentile(latencies, 50)
        p90 = self._percentile(latencies, 90)
        p95 = self._percentile(latencies, 95)
        p99 = self._percentile(latencies, 99)

        avg_ttfb = statistics.mean(ttfb_list) if ttfb_list else 0.0
        avg_stream = statistics.mean(stream_list) if stream_list else 0.0
        avg_chunk_bytes = statistics.mean(all_sizes) if all_sizes else 0.0
        avg_chunk_interval_ms = statistics.mean(all_intervals) if all_intervals else 0.0

        avg_cpu = statistics.mean(self.cpu_samples) if self.cpu_samples else 0.0
        avg_mem = statistics.mean(self.mem_samples) if self.mem_samples else 0.0
        avg_net_up = statistics.mean(self.net_up_samples) if self.net_up_samples else 0.0
        avg_net_down = statistics.mean(self.net_down_samples) if self.net_down_samples else 0.0

        return {
            "avg_latency_ms": avg_latency,
            "min_latency_ms": min_latency,
            "max_latency_ms": max_latency,
            "p50_latency_ms": p50,
            "p90_latency_ms": p90,
            "p95_latency_ms": p95,
            "p99_latency_ms": p99,
            "avg_ttfb_ms": avg_ttfb,
            "avg_stream_ms": avg_stream,
            "total_chunks": total_chunks,
            "avg_chunk_bytes": avg_chunk_bytes,
            "avg_chunk_interval_ms": avg_chunk_interval_ms,
            "avg_cpu": avg_cpu,
            "avg_mem": avg_mem,
            "avg_net_up_kb": avg_net_up,
            "avg_net_down_kb": avg_net_down,
        }

    # —— 写 CSV 汇总行 —— #
    def write_csv_summary(self, start_ts: float, end_ts: float, mode: str, max_users: int) -> None:
        summary = self.aggregate()
        if not summary:
            return

        self.csv_path.parent.mkdir(parents=True, exist_ok=True)
        exists = self.csv_path.exists()

        import time
        start_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_ts))
        end_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(end_ts))

        total_requests = len(self.records)
        success = sum(1 for r in self.records if r.ok)
        fail = total_requests - success

        total_seconds = end_ts - start_ts
        avg_tps = total_requests / total_seconds if total_seconds > 0 else 0.0

        with self.csv_path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if not exists:
                writer.writerow([
                    "压测开始时间",
                    "压测结束时间",
                    "模式",
                    "最大并发数",
                    "总请求数",
                    "成功数",
                    "失败数",
                    "平均响应时间(ms)",
                    "最小响应时间(ms)",
                    "最大响应时间(ms)",
                    "P50响应时间(ms)",
                    "P90响应时间(ms)",
                    "P95响应时间(ms)",
                    "P99响应时间(ms)",
                    "平均首字节时间(ms)",
                    "平均流式持续时间(ms)",
                    "总块数",
                    "平均块大小(Byte)",
                    "平均块间隔(ms)",
                    "平均TPS",
                    "平均CPU使用率(%)",
                    "平均内存使用率(%)",
                    "平均上行带宽(KB/s)",
                    "平均下行带宽(KB/s)"
                ])

            writer.writerow([
                start_str,
                end_str,
                mode,
                max_users,
                total_requests,
                success,
                fail,
                f"{summary['avg_latency_ms']:.2f}",
                f"{summary['min_latency_ms']:.2f}",
                f"{summary['max_latency_ms']:.2f}",
                f"{summary['p50_latency_ms']:.2f}",
                f"{summary['p90_latency_ms']:.2f}",
                f"{summary['p95_latency_ms']:.2f}",
                f"{summary['p99_latency_ms']:.2f}",
                f"{summary['avg_ttfb_ms']:.2f}",
                f"{summary['avg_stream_ms']:.2f}",
                summary["total_chunks"],
                f"{summary['avg_chunk_bytes']:.2f}",
                f"{summary['avg_chunk_interval_ms']:.2f}",
                f"{avg_tps:.2f}",
                f"{summary['avg_cpu']:.2f}",
                f"{summary['avg_mem']:.2f}",
                f"{summary['avg_net_up_kb']:.2f}",
                f"{summary['avg_net_down_kb']:.2f}",
            ])
