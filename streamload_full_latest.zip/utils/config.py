from __future__ import annotations

import configparser
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Dict

ModeType = Literal["dual", "stream_a", "stream_b"]


@dataclass
class AppConfig:
    """统一的配置对象，供 runner / client 使用。"""

    mode: ModeType
    duration_seconds: int
    max_users: int
    ramp_users_per_sec: float
    timeout_seconds: int
    verify_ssl: bool

    chat_url: str
    callback_url: str
    stream_a_url: str
    stream_b_url: str

    headers: Dict[str, str]
    logging_level: str


def load_config(path: Path) -> AppConfig:
    """从 config.ini 读取配置并封装为 AppConfig。"""
    if not path.exists():
        raise FileNotFoundError(f"config.ini 未找到: {path}")

    parser = configparser.ConfigParser()
    parser.read(path, encoding="utf-8")

    mode = parser.get("pressure", "mode", fallback="dual").strip()
    if mode not in ("dual", "stream_a", "stream_b"):
        raise ValueError(f"pressure.mode 必须是 dual/stream_a/stream_b，其它值不支持: {mode}")

    duration_seconds = parser.getint("pressure", "duration_seconds", fallback=60)
    max_users = parser.getint("pressure", "max_users", fallback=5)
    ramp_users_per_sec = parser.getfloat("pressure", "ramp_users_per_sec", fallback=1.0)
    timeout_seconds = parser.getint("pressure", "timeout_seconds", fallback=30)
    verify_ssl = parser.getboolean("pressure", "verify_ssl", fallback=True)

    chat_url = parser.get("urls", "chat_url", fallback="")
    callback_url = parser.get("urls", "callback_url", fallback="")
    stream_a_url = parser.get("urls", "stream_a_url", fallback="")
    stream_b_url = parser.get("urls", "stream_b_url", fallback="")

    headers: Dict[str, str] = {}
    ct = parser.get("headers", "content_type", fallback="application/json").strip()
    if ct:
        headers["Content-Type"] = ct
    auth = parser.get("headers", "authorization", fallback="").strip()
    if auth:
        headers["Authorization"] = auth

    logging_level = parser.get("logging", "level", fallback="INFO").upper()

    return AppConfig(
        mode=mode,  # type: ignore[arg-type]
        duration_seconds=duration_seconds,
        max_users=max_users,
        ramp_users_per_sec=ramp_users_per_sec,
        timeout_seconds=timeout_seconds,
        verify_ssl=verify_ssl,
        chat_url=chat_url,
        callback_url=callback_url,
        stream_a_url=stream_a_url,
        stream_b_url=stream_b_url,
        headers=headers,
        logging_level=logging_level,
    )
