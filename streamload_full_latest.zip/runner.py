from __future__ import annotations

import asyncio
import time
from typing import List

import psutil

from utils.config import AppConfig
from utils.data_loader import DataLoader
from utils.recorder import ResultRecorder
from clients.dual_client import DualClient
from clients.stream_client_a import StreamClientA
from clients.stream_client_b import StreamClientB


class LoadRunner:
    """压测调度器：根据 mode 选择不同客户端，控制并发和时间。"""

    def __init__(self, cfg: AppConfig, logger, data_loader: DataLoader, recorder: ResultRecorder) -> None:
        self.cfg = cfg
        self.logger = logger
        self.data_loader = data_loader
        self.recorder = recorder

        self.start_time: float = 0.0
        self.end_time: float = 0.0

        self.success: int = 0
        self.fail: int = 0
        self.peak_tps: float = 0.0

        net = psutil.net_io_counters()
        self.last_sent = net.bytes_sent
        self.last_recv = net.bytes_recv

    async def run(self) -> None:
        self.start_time = time.time()
        tasks: List[asyncio.Task] = []
        current_users = 0
        last_status_time = 0.0

        while True:
            now = time.time()
            elapsed = now - self.start_time
            if elapsed >= self.cfg.duration_seconds:
                break

            allow_users = min(self.cfg.max_users, int(elapsed * self.cfg.ramp_users_per_sec) + 1)

            while current_users < allow_users:
                uid = current_users + 1
                task = asyncio.create_task(self.run_user(uid))
                tasks.append(task)
                current_users += 1
                self.logger.info("[调度] 新增并发用户 -> %s", current_users)

            if now - last_status_time >= 1.0:
                self._log_status(elapsed, current_users)
                last_status_time = now

            await asyncio.sleep(0.2)

        self.logger.info("等待所有并发用户任务结束...")
        await asyncio.gather(*tasks, return_exceptions=True)

        self.end_time = time.time()
        self._log_summary()
        self.recorder.write_csv_summary(self.start_time, self.end_time, self.cfg.mode, self.cfg.max_users)

    async def run_user(self, user_id: int) -> None:
        if self.cfg.mode == "dual":
            ClientCls = DualClient
        elif self.cfg.mode == "stream_a":
            ClientCls = StreamClientA
        else:
            ClientCls = StreamClientB

        self.logger.info("[用户%s] 启动 | 模式=%s", user_id, self.cfg.mode)

        async with ClientCls(self.cfg, self.logger, self.data_loader, self.recorder, user_id) as client:
            while True:
                now = time.time()
                if now - self.start_time >= self.cfg.duration_seconds:
                    break
                try:
                    ok = await client.run_once()
                    if ok:
                        self.success += 1
                    else:
                        self.fail += 1
                except Exception as exc:  # noqa: BLE001
                    self.fail += 1
                    self.logger.error("[用户%s] 请求异常: %r", user_id, exc)

    def _log_status(self, elapsed: float, current_users: int) -> None:
        total = self.success + self.fail
        tps = total / elapsed if elapsed > 0 else 0.0
        self.peak_tps = max(self.peak_tps, tps)

        cpu = psutil.cpu_percent(interval=0)
        mem = psutil.virtual_memory().percent

        net = psutil.net_io_counters()
        sent_kb = (net.bytes_sent - self.last_sent) / 1024
        recv_kb = (net.bytes_recv - self.last_recv) / 1024
        self.last_sent = net.bytes_sent
        self.last_recv = net.bytes_recv

        remaining = self.cfg.duration_seconds - elapsed
        progress = (elapsed / self.cfg.duration_seconds) * 100 if self.cfg.duration_seconds > 0 else 0

        self.logger.info(
            "[状态] 模式=%s | 并发=%s/%s | 成功=%s 失败=%s | TPS=%.2f 峰值=%.2f | "
            "CPU=%.1f%% MEM=%.1f%% | ↑%.1fKB/s ↓%.1fKB/s | 运行=%.1fs 剩余=%.1fs 进度=%.1f%%",
            self.cfg.mode,
            current_users,
            self.cfg.max_users,
            self.success,
            self.fail,
            tps,
            self.peak_tps,
            cpu,
            mem,
            sent_kb,
            recv_kb,
            elapsed,
            remaining,
            progress,
        )

        self.recorder.add_system_sample(cpu, mem, sent_kb, recv_kb)

    def _log_summary(self) -> None:
        total = self.success + self.fail
        dur = self.end_time - self.start_time
        avg_tps = total / dur if dur > 0 else 0.0

        self.logger.info("========= 压测汇总 =========")
        self.logger.info("模式              : %s", self.cfg.mode)
        self.logger.info("开始时间          : %s",
                         time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.start_time)))
        self.logger.info("结束时间          : %s",
                         time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.end_time)))
        self.logger.info("总耗时(秒)        : %.2f", dur)
        self.logger.info("总请求数          : %s", total)
        self.logger.info("成功/失败         : %s / %s", self.success, self.fail)
        self.logger.info("平均TPS           : %.2f", avg_tps)
        self.logger.info("峰值TPS           : %.2f", self.peak_tps)

        summary = self.recorder.aggregate()
        if not summary:
            return

        self.logger.info("------ 响应时间(ms) ------")
        self.logger.info("平均响应时间      : %.2f", summary["avg_latency_ms"])
        self.logger.info("最小响应时间      : %.2f", summary["min_latency_ms"])
        self.logger.info("最大响应时间      : %.2f", summary["max_latency_ms"])
        self.logger.info("P50响应时间       : %.2f", summary["p50_latency_ms"])
        self.logger.info("P90响应时间       : %.2f", summary["p90_latency_ms"])
        self.logger.info("P95响应时间       : %.2f", summary["p95_latency_ms"])
        self.logger.info("P99响应时间       : %.2f", summary["p99_latency_ms"])

        self.logger.info("------ 流式相关 ------")
        self.logger.info("平均首字节时间    : %.2f", summary["avg_ttfb_ms"])
        self.logger.info("平均流式耗时      : %.2f", summary["avg_stream_ms"])
        self.logger.info("总块数            : %s", summary["total_chunks"])
        self.logger.info("平均块大小(Byte)  : %.2f", summary["avg_chunk_bytes"])
        self.logger.info("平均块间隔(ms)    : %.2f", summary["avg_chunk_interval_ms"])

        self.logger.info("------ 系统资源平均 ------")
        self.logger.info("平均CPU使用率(%%) : %.2f", summary["avg_cpu"])
        self.logger.info("平均内存使用率(%%): %.2f", summary["avg_mem"])
        self.logger.info("平均上行KB/s      : %.2f", summary["avg_net_up_kb"])
        self.logger.info("平均下行KB/s      : %.2f", summary["avg_net_down_kb"])
