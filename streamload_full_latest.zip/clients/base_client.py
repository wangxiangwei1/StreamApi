from __future__ import annotations

import httpx
import psutil


class BaseClient:
    """所有具体 Client 的基类，负责 http 客户端和通用日志。"""

    def __init__(self, cfg, logger, data_loader, recorder, user_id: int) -> None:
        self.cfg = cfg
        self.logger = logger
        self.data_loader = data_loader
        self.recorder = recorder
        self.user_id = user_id
        self.client: httpx.AsyncClient | None = None

    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            timeout=self.cfg.timeout_seconds,
            verify=self.cfg.verify_ssl,
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self.client is not None:
            await self.client.aclose()

    def snapshot(self) -> tuple[float, float]:
        cpu = psutil.cpu_percent(interval=0)
        mem = psutil.virtual_memory().percent
        return cpu, mem

    def log_single(self, url: str, status: int, cost: float, preview: str) -> None:
        self.logger.info(
            "[请求] 用户%s | URL=%s | 状态=%s | 耗时=%.3fs | 预览: %s",
            self.user_id,
            url,
            status,
            cost,
            preview[:80].replace("\n", " "),
        )

    def log_dual(
        self,
        chat_url: str,
        cb_url: str,
        chat_status: int,
        cb_status: int,
        chat_time: float,
        cb_time: float,
        preview: str,
    ) -> None:
        total = chat_time + cb_time
        self.logger.info(
            "[链路] 用户%s | chat=%s(%.3fs) → callback=%s(%.3fs) | 总耗时=%.3fs\n"
            "       chat: %s\n"
            "       cb  : %s\n"
            "       预览: %s",
            self.user_id,
            chat_status,
            chat_time,
            cb_status,
            cb_time,
            total,
            chat_url,
            cb_url,
            preview[:80].replace("\n", " "),
        )
