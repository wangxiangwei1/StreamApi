from __future__ import annotations

import time
import httpx

from utils.recorder import RequestRecord
from .base_client import BaseClient


class StreamClientB(BaseClient):
    """独立流式接口 B。"""

    async def run_once(self) -> bool:
        assert self.client is not None

        url = self.cfg.stream_b_url
        payload = self.data_loader.next_stream_b_payload()
        payload["inputText"] = self.data_loader.next_question()

        t_req_start = time.time()

        try:
            async with self.client.stream("POST", url, json=payload, headers=self.cfg.headers) as resp:
                status = resp.status_code
                first_chunk_time = None
                last_chunk_time = None
                chunks = 0
                sizes = []
                intervals = []
                preview_parts = []

                async for chunk in resp.aiter_bytes():
                    now = time.time()
                    if first_chunk_time is None:
                        first_chunk_time = now
                        last_chunk_time = now
                    else:
                        intervals.append(now - last_chunk_time)
                        last_chunk_time = now

                    sizes.append(len(chunk))
                    chunks += 1
                    try:
                        text = chunk.decode("utf-8", errors="ignore")
                        preview_parts.append(text)
                    except Exception:
                        pass

                if first_chunk_time is not None and last_chunk_time is not None:
                    ttfb = first_chunk_time - t_req_start          # ✅ 统一 TTFB
                    stream_cost = last_chunk_time - first_chunk_time
                    preview = "".join(preview_parts)[:200]
                else:
                    ttfb = 0.0
                    stream_cost = 0.0
                    preview = ""
        except httpx.HTTPError as e:
            self.logger.error("[B] 请求异常: %r", e)
            self.recorder.add_record(
                RequestRecord("stream_b", False, time.time() - t_req_start, 0.0, 0.0, 0)
            )
            return False

        total_time = time.time() - t_req_start
        ok = status == 200
        cpu, mem = self.snapshot()

        self.log_single(url, status, total_time, preview)

        self.recorder.add_record(
            RequestRecord(
                mode="stream_b",
                ok=ok,
                time_cost=total_time,
                ttfb=ttfb,
                stream_cost=stream_cost,
                chunks=chunks,
                chunk_sizes=sizes,
                chunk_intervals=intervals,
                cpu=cpu,
                mem=mem,
            )
        )

        return ok
