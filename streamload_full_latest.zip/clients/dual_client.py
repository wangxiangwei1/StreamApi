from __future__ import annotations

import time
import json
import httpx

from utils.ids import generate_conversation_id
from utils.recorder import RequestRecord
from .base_client import BaseClient


class DualClient(BaseClient):
    """chat + callback 双接口依赖链路。"""

    async def run_once(self) -> bool:
        assert self.client is not None

        # —— 构造 chat 请求参数 —— #
        payload = self.data_loader.next_chat_payload()
        payload["inputText"] = self.data_loader.next_question()
        payload["conversationId"] = generate_conversation_id()

        chat_url = self.cfg.chat_url
        cb_url = self.cfg.callback_url

        t0 = time.time()

        # 1) chat 请求（非流式）
        try:
            chat_resp = await self.client.post(chat_url, json=payload, headers=self.cfg.headers)
        except httpx.HTTPError as e:
            self.logger.error("[Dual] chat 请求异常: %r", e)
            self.recorder.add_record(RequestRecord("dual", False, time.time() - t0, 0.0, 0.0, 0))
            return False

        t_chat = time.time() - t0

        if chat_resp.status_code != 200:
            self.logger.error("[Dual] chat HTTP %s", chat_resp.status_code)
            self.recorder.add_record(RequestRecord("dual", False, t_chat, 0.0, 0.0, 0))
            return False

        try:
            data = chat_resp.json()
        except json.JSONDecodeError:
            self.logger.error("[Dual] chat 响应不是有效 JSON")
            self.recorder.add_record(RequestRecord("dual", False, t_chat, 0.0, 0.0, 0))
            return False

        request_id = data.get("requestId") or data.get("data", {}).get("requestId")
        if not request_id:
            self.logger.error("[Dual] chat 响应中没有 requestId 字段")
            self.recorder.add_record(RequestRecord("dual", False, t_chat, 0.0, 0.0, 0))
            return False

        # 2) callback 请求（流式）
        t_req_start = time.time()
        try:
            async with self.client.stream("GET", cb_url, params={"requestId": request_id}, headers=self.cfg.headers) as resp:
                status = resp.status_code
                first_chunk_time = None
                last_chunk_time = None
                chunks = 0
                sizes = []
                intervals = []
                preview_parts = []

                async for chunk in resp.aiter_bytes():
                    now = time.time()
                    if first_chunk_time is None:
                        first_chunk_time = now
                        last_chunk_time = now
                    else:
                        intervals.append(now - last_chunk_time)
                        last_chunk_time = now

                    sizes.append(len(chunk))
                    chunks += 1
                    try:
                        text = chunk.decode("utf-8", errors="ignore")
                        preview_parts.append(text)
                    except Exception:
                        pass

                if first_chunk_time is not None and last_chunk_time is not None:
                    ttfb = first_chunk_time - t_req_start         # ✅ TTFB 统一：请求开始 → 首块到达
                    stream_cost = last_chunk_time - first_chunk_time
                    preview = "".join(preview_parts)[:200]
                else:
                    ttfb = 0.0
                    stream_cost = 0.0
                    preview = ""
        except httpx.HTTPError as e:
            self.logger.error("[Dual] callback 请求异常: %r", e)
            self.recorder.add_record(RequestRecord("dual", False, time.time() - t0, 0.0, 0.0, 0))
            return False

        t_cb = time.time() - t_req_start
        total_time = time.time() - t0
        ok = chat_resp.status_code == 200 and status == 200

        cpu, mem = self.snapshot()

        self.log_dual(chat_url, cb_url, chat_resp.status_code, status, t_chat, t_cb, preview)

        self.recorder.add_record(
            RequestRecord(
                mode="dual",
                ok=ok,
                time_cost=total_time,
                ttfb=ttfb,
                stream_cost=stream_cost,
                chunks=chunks,
                chunk_sizes=sizes,
                chunk_intervals=intervals,
                cpu=cpu,
                mem=mem,
            )
        )

        return ok
