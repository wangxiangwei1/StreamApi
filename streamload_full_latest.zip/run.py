from pathlib import Path
import asyncio

from utils.config import load_config
from utils.logger import setup_logger
from utils.data_loader import DataLoader
from utils.recorder import ResultRecorder
from runner import LoadRunner


async def main() -> None:
    """压测入口：加载配置 -> 初始化组件 -> 启动 Runner。"""
    base = Path(__file__).resolve().parent

    # 1. 加载配置
    cfg = load_config(base / "config.ini")

    # 2. 日志
    logger = setup_logger(base / "logs", cfg.logging_level)

    logger.info("============== 压测启动 ==============")
    logger.info("模式: %s", cfg.mode)
    logger.info(
        "最大并发: %s | 持续: %s 秒 | 每秒增加: %s",
        cfg.max_users,
        cfg.duration_seconds,
        cfg.ramp_users_per_sec,
    )

    # 3. 数据加载
    data_loader = DataLoader(base / "data")

    # 4. 结果记录器
    recorder = ResultRecorder(base / "results" / "result.csv")

    # 5. 启动调度器
    runner = LoadRunner(cfg, logger, data_loader, recorder)
    await runner.run()

    logger.info("============== 压测结束 ==============")


if __name__ == "__main__":
    asyncio.run(main())
